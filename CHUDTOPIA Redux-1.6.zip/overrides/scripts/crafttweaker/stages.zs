println("The Script Is Working!");

import crafttweaker.forge.api.event.interact.EntityInteractEvent;
import crafttweaker.api.util.InteractionHand;
import mods.gamestages.StageHelper;
import mods.recipestages.Recipes;



//Stage 0: Beginnings
mods.recipestages.Recipes.setRecipeStageByMod("zero", "minecraft");

//Stage 1: Colonization

mods.recipestages.Recipes.setRecipeStageByMod("one", "minecolonies");
mods.recipestages.Recipes.setRecipeStageByMod("one", "totemic");
mods.recipestages.Recipes.setRecipeStageByMod("one", "tconstruct");
mods.recipestages.Recipes.setRecipeStageByMod("one", "aether");
mods.recipestages.Recipes.setRecipeStageByMod("one", "domumornamentum");
mods.recipestages.Recipes.setRecipeStageByMod("one", "structurize");
mods.recipestages.Recipes.setRecipeStageByMod("one", "ironchest");
mods.recipestages.Recipes.setRecipeStageByMod("one", "additional_lights");
mods.recipestages.Recipes.setRecipeStageByMod("one", "magistuarmory");

//Mini Stages
mods.recipestages.Recipes.setRecipeStageByMod("embers", "embers");
mods.recipestages.Recipes.setRecipeStageByMod("arsnouveau", "ars_nouveau");
mods.recipestages.Recipes.clearRecipeStage(<item:ars_nouveau:archmage_spell_book>);
mods.recipestages.Recipes.setRecipeStageByMod("arsnouveau", "ars_artillery");
mods.recipestages.Recipes.setRecipeStageByMod("arsnouveau", "ars_elemental");
mods.recipestages.Recipes.setRecipeStageByMod("botania", "botania");
mods.recipestages.Recipes.setRecipeStageByMod("create", "create");
mods.recipestages.Recipes.setRecipeStageByMod("create", "create_new_age");
mods.recipestages.Recipes.setRecipeStageByMod("create", "createreexcavation");
mods.recipestages.Recipes.setRecipeStageByMod("create", "railways");
mods.recipestages.Recipes.setRecipeStageByMod("thermal", "thermal");
mods.recipestages.Recipes.setRecipeStageByMod("immersiveengineering", "immersiveengineering");
mods.recipestages.Recipes.setRecipeStageByMod("forestry", "forestry");
mods.recipestages.Recipes.setRecipeStageByMod("forestry", "gendustry");
mods.recipestages.Recipes.setRecipeStageByMod("bloodmagic", "bloodmagic");
mods.recipestages.Recipes.setRecipeStageByMod("pneumaticraft", "pneumaticcraft");
mods.recipestages.Recipes.setRecipeStageByMod("eidolon", "eidolon");


//Stage 2: Consolidation
mods.recipestages.Recipes.setRecipeStageByMod("two", "securitycraft");
mods.recipestages.Recipes.setRecipeStageByMod("two", "sophisticatedbackpacks");
mods.recipestages.Recipes.setRecipeStageByMod("two", "sereneseasons");
mods.recipestages.Recipes.setRecipeStageByMod("two", "twilightforest");
mods.recipestages.Recipes.setRecipeStageByMod("two", "alltheores");
mods.recipestages.Recipes.setRecipeStageByMod("two", "ironfurnaces");
mods.recipestages.Recipes.setRecipeStageByMod("scguns", "scguns");

//Stage 3: Chuddification
mods.recipestages.Recipes.setRecipeStageByMod("mekanism", "mekanismgenerators");
mods.recipestages.Recipes.setRecipeStageByMod("three", "mffs");
mods.recipestages.Recipes.setRecipeStageByMod("mekanism", "mekanism");
mods.recipestages.Recipes.setRecipeStageByMod("mysticalagriculture", "mysticalagriculture");
mods.recipestages.Recipes.setRecipeStageByMod("mysticalagriculture", "mysticalagradditions");
mods.recipestages.Recipes.setRecipeStageByMod("ae2", "ae2");
mods.recipestages.Recipes.setRecipeStageByMod("powah", "powah");
mods.recipestages.Recipes.setRecipeStageByMod("adastra", "ad_astra");
mods.recipestages.Recipes.setRecipeStageByMod("voltaic", "voltaic");
mods.recipestages.Recipes.setRecipeStageByMod("occultism", "occultism");
mods.recipestages.Recipes.setRecipeStageByMod("warium", "crusty_chunks");

//Weapon Stages
mods.recipestages.Recipes.setRecipeStageByMod("artillery", "createbigcannons");
mods.recipestages.Recipes.setRecipeStageByMod("navy", "vs_eureka");
mods.recipestages.Recipes.setRecipeStageByMod("airforce", "vs_clockwork");
mods.recipestages.Recipes.setRecipeStageByMod("rocketry", "simplehandmissile");
mods.recipestages.Recipes.setRecipeStageByMod("tanks", "trackwork");


//Stage 4: [STRENG GEHEIM]
mods.recipestages.Recipes.setRecipeStageByMod("four", "ballistix");
mods.recipestages.Recipes.setRecipeStageByMod("four", "nuclearscience");
mods.recipestages.Recipes.setRecipeStageByMod("four", "voltaic");
mods.recipestages.Recipes.setRecipeStageByMod("four", "electrodynamics");

//Stage 5: The End of All Things
mods.recipestages.Recipes.setRecipeStageByMod("draconic", "draconicevolution");


