ServerEvents.recipes(event => {
  // Remove the original fan-washing recipe involving Soul Soil
  event.remove({ input: 'minecraft:soul_soil', type: 'create:splashing' })

  // Add a new version with reduced drop rates
  event.custom({
    type: 'create:splashing',
    ingredients: [{ item: 'minecraft:soul_soil' }],
    results: [
      { item: 'minecraft:quartz', chance: 0.05 },
      { item: 'scguns:anthralite_nugget', chance: 0.2 }
    ]
  })
})