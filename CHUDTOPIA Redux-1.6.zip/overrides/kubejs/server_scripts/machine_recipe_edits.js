ServerEvents.recipes(event => {
  // Remove existing gravel washing recipe
  event.remove({ id: 'create:splashing/gravel' })

  // Add a custom version with reduced nugget chance
  event.custom({
    type: 'create:splashing',
    ingredients: [
      { item: 'minecraft:gravel' }
    ],
    results: [
      { item: 'minecraft:flint', chance: 0.25 },             
      { item: 'minecraft:iron_nugget', chance: 0.04 },     
      { item: 'minecraft:sand', chance: 0.02 }       
    ]
  })
  event.remove({ id: 'create:splashing/red_sand' })

  event.custom({
    type: 'create:splashing',
    ingredients: [
        {item: 'minecraft:red_sand'}
    ],
    results: [
        { item: 'minecraft:dead_bush', chance: 0.05},
        { item : 'minecraft:gold_nugget', chance: 0.02}
    ]
  })
  event.remove({ id: 'create:splashing/soul_sand' })


  event.custom({
    type: 'create:splashing',
    ingredients: [
      { item: 'minecraft:soul_sand' }
    ],
    results: [
      { item: 'minecraft:quartz', chance: 0.02 },             
      { item: 'minecraft:gold_nugget', chance: 0.02 },        
      { item: 'minecraft:sand', chance: 0.02 }       
    ]
  })
  event.remove({ id: 'create:splashing/red_sand' })

  event.custom({
    type: 'create:splashing',
    ingredients: [
        {item: 'minecraft:red_sand'}
    ],
    results: [
        { item: 'minecraft:dead_bush', chance: 0.05},
        { item : 'minecraft:gold_nugget', chance: 0.02}
    ]
  })
  event.remove({ input: 'minecraft:tuff' , type: 'create:crushing' })

  event.custom({
    type: 'create:crushing',
    ingredients: [{ item: 'minecraft:tuff' }],
    results: [
        { item: 'minecraft:flint', chance: 0.1},
        { item: 'create:zinc_nugget', chance: 0.02},
        { item: 'minecraft:gold_nugget', chance: 0.02},
        { item: 'create:copper_nugget', chance: 0.02},
    ]
  })
})  
