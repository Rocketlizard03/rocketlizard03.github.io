ServerEvents.recipes(event => {
  // Step 1: Remove the existing recipe
  event.remove({ output: 'mekanism:chemical_dissolution_chamber' });

  // Step 2: Add your custom shaped recipe
  event.shaped('mekanism:chemical_dissolution_chamber', [
    'AGA',
    'RCR',
    'ATA'
  ], {
    A: 'mekanism:alloy_atomic',
    G: 'mekanism:elite_control_circuit',
    R: 'mekanism:steel_casing',
    C: 'botania:manasteel_block',
    T: 'mekanism:ultimate_chemical_tank'
  }).id('custom:chemical_dissolution_chamber');
});

ServerEvents.recipes(event => {
  // === Lapis Seeds ===
  event.remove({ output: 'mysticalagriculture:lapis_lazuli_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: {
      item: 'mysticalagriculture:prosperity_seed_base'
    },
    ingredients: [
      { item: 'tconstruct:hepatizon_block'},
      { item: 'tconstruct:cobalt_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'minecraft:lapis_block' },
      { item: 'minecraft:lapis_block' },
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'tconstruct:cobalt_block'},
      { item: 'tconstruct:hepatizon_block'},
    ],
    result: {
      item: 'mysticalagriculture:lapis_lazuli_seeds'
    },
    crafting_time: 400,
    essence_type: 'mysticalagriculture:lapis_lazuli_essence'
  }).id('custom:lapis_lazuli_seeds');


  // === Iron Seeds ===
  event.remove({ output: 'mysticalagriculture:iron_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: {
      item: 'mysticalagriculture:prosperity_seed_base'
    },
    ingredients: [
      { item: 'minecraft:iron_block'},
      { item: 'minecraft:iron_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'minecraft:iron_block'},
      { item: 'minecraft:iron_block'},
    ],
    result: {
      item: 'mysticalagriculture:iron_seeds'
    },
    crafting_time: 200,
    essence_type: 'mysticalagriculture:iron_essence'
  }).id('custom:iron_seeds');
// === Copper Seeds ===
  event.remove({ output: 'mysticalagriculture:copper_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'minecraft:copper_block'},
      { item: 'minecraft:copper_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'minecraft:copper_block'},
      { item: 'minecraft:copper_block'},
    ],
    result: { item: 'mysticalagriculture:copper_seeds' },
    crafting_time: 200
  }).id('custom:copper_seeds');

  // === Redstone Seeds ===
  event.remove({ output: 'mysticalagriculture:redstone_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'minecraft:redstone_block'},
      { item: 'minecraft:redstone_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'mysticalagriculture:tertium_ingot_block'},
      { item: 'minecraft:redstone_block'},
      { item: 'minecraft:redstone_block'}
    ],
    result: { item: 'mysticalagriculture:redstone_seeds' },
    crafting_time: 200
  }).id('custom:redstone_seeds');

  // === Enderman Seeds ===
  event.remove({ output: 'mysticalagriculture:enderman_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'ars_nouveau:ritual_flight'},
      { item: 'minecraft:ender_pearl' },
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'ars_nouveau:ritual_flight'},
      { item: 'minecraft:ender_pearl' }
    ],
    result: { item: 'mysticalagriculture:enderman_seeds' },
    crafting_time: 200
  }).id('custom:enderman_seeds');

  // === Uranium Seeds (Mekanism) ===
  event.remove({ output: 'mysticalagriculture:uranium_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'mekanism:ingot_uranium' },
      { item: 'mekanism:ingot_uranium' },
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mekanism:ingot_uranium' },
      { item: 'mekanism:ingot_uranium' }
    ],
    result: { item: 'mysticalagriculture:uranium_seeds' },
    crafting_time: 200
  }).id('custom:uranium_seeds');

  // === Diamond Seeds ===
  event.remove({ output: 'mysticalagriculture:diamond_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'minecraft:diamond_block' },
      { item: 'minecraft:diamond_block' },
      { item: 'minecraft:diamond_block' },
      { item: 'minecraft:diamond_block' },
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
    ],
    result: { item: 'mysticalagriculture:diamond_seeds' },
    crafting_time: 200
  }).id('custom:diamond_seeds');

  // === Gold Seeds ===
  event.remove({ output: 'mysticalagriculture:gold_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'minecraft:gold_ingot' },
      { item: 'thermal:electrum_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'thermal:electrum_block'},
      { item: 'minecraft:gold_ingot' }
    ],
    result: { item: 'mysticalagriculture:gold_seeds' },
    crafting_time: 200
  }).id('custom:gold_seeds');

  // === Emerald Seeds ===
  event.remove({ output: 'mysticalagriculture:emerald_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'minecraft:emerald_block' },
      { item: 'minecraft:emerald_block' },
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'mysticalagriculture:supremium_ingot_block'},
      { item: 'minecraft:emerald_block' },
      { item: 'minecraft:emerald_block' },
    ],
    result: { item: 'mysticalagriculture:emerald_seeds' },
    crafting_time: 200
  }).id('custom:emerald_seeds');

  // === Osmium Seeds (Mekanism) ===
  event.remove({ output: 'mysticalagriculture:osmium_seeds' });
  event.custom({
    type: 'mysticalagriculture:infusion',
    input: { item: 'mysticalagriculture:prosperity_seed_base' },
    ingredients: [
      { item: 'mekanism:block_osmium'},
      { item: 'mekanism:block_osmium'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mysticalagriculture:imperium_ingot_block'},
      { item: 'mekanism:block_osmium'},
      { item: 'mekanism:block_osmium'}
    ],
    result: { item: 'mysticalagriculture:osmium_seeds' },
    crafting_time: 200
  }).id('custom:osmium_seeds');

  // == Infusion Crafting Pedestal
  event.remove({ output: 'mysticalagriculture:infusion_pedestal' });
  event.shaped('mysticalagriculture:infusion_pedestal', [
    'AGA',
    'BCB',
    'BCB'
  ], {
    A: 'minecraft:gold_block',
    G: 'minecraft:redstone_block',
    C: 'mysticalagriculture:inferium_block',
    B: 'minecraft:air'
    }).id('custom:infusion_pedestal');

   // == Infusion Crafting Altar
  event.remove({ output: 'mysticalagriculture:infusion_altar' });
  event.shaped('mysticalagriculture:infusion_altar', [
    'AGA',
    'BCB',
    'CCC'
  ], {
    A: 'minecraft:gold_block',
    G: 'minecraft:redstone_block',
    C: 'mysticalagriculture:inferium_block',
    B: 'minecraft:air'
  }).id('custom:infusion_altar');
});

// ===Recipe Unifications===
ServerEvents.recipes(event => {
  // ==CopperGear==
  event.remove({ output: 'thermal:copper_gear' });
  event.remove({ output: 'forestry:gear_copper' });
  event.remove({ output: 'electrodynamics:gearcopper' });
   // Tin
  event.remove({ output: 'thermal:tin_gear' })
  event.remove({ output: 'forestry:gear_tin' })
  event.remove({ output: 'electrodynamics:geartin' })

  // Iron
  event.remove({ output: 'thermal:iron_gear' })
  event.remove({ output: 'forestry:gear_iron' })
  event.remove({ output: 'electrodynamics:geariron' })

  // Gold
  event.remove({ output: 'thermal:gold_gear' })
  event.remove({ output: 'forestry:gear_gold' })
  event.remove({ output: 'electrodynamics:geargold' })

  // Lead
  event.remove({ output: 'thermal:lead_gear' })
  event.remove({ output: 'electrodynamics:gearlead' })

  // Silver
  event.remove({ output: 'thermal:silver_gear' })
  event.remove({ output: 'electrodynamics:gearsilver' })

  // Uranium (sometimes uraninite)
  event.remove({ output: 'electrodynamics:gearuraninite' })
  event.remove({ output: 'mekanism:gear_uranium' }) // if Mekanism adds one

  // BronzeGear
  event.remove({ output: 'thermal:bronze_gear' })
  event.remove({ output: 'forestry:gear_bronze' })

  // ==GunpowderDust==
  event.remove({ output: 'createbigcannons:gunpowder_pinch' });

  // ==Steel Ingots==
  event.remove({ output: 'electrodynamics:ingotsteel' })
  event.remove({ output: 'mekanism:ingot_steel' })
  event.remove({ output: 'immersiveengineering:ingot_steel' })
  event.remove({ output: 'mffs:steel_ingot' })
  event.remove({ output: 'tconstruct:steel_ingot' })
  event.remove({ output: 'magistuarmory:steel_ingot' })
  event.remove({ output: 'thermal:steel_ingot' })
  event.remove({ output: 'ad_astra:steel_ingot' })

  // ==Steel Nuggets==
   event.remove({ output: 'electrodynamics:nuggetsteel' })
  event.remove({ output: 'mekanism:nugget_steel' })
  event.remove({ output: 'immersiveengineering:nugget_steel' })
  event.remove({ output: 'mffs:steel_nugget' })
  event.remove({ output: 'tconstruct:steel_nugget' })
  event.remove({ output: 'thermal:steel_nugget' })
  event.remove({ output: 'ad_astra:steel_nugget' })

  // ==Brass Blocks==
  event.remove({
    type: 'tconstruct:casting_basin',
    output: 'create:brass_block'
  })
  event.custom({
    type: 'tconstruct:casting_basin',
    cast: {
      tag: 'tconstruct:casts/basin'
    },
    cast_consumed: false,
    fluid: {
      name: 'tconstruct:molten_brass',
      amount: 1296    // 9 ingots × 144 mB each
    },
    result: {
      item: 'alltheores:brass_block'
    },
    cooling_time: 60   // in ticks (60 ticks = 3 s)
  }),

  // ==Ars Nouveau==
  event.remove({ output: 'ars_nouveau:archmage_spell_book'})

})

// Nuke Unifications
  ServerEvents.recipes(event => {
    event.remove({ output: 'crusty_chunks:fission_bomb'})
    event.remove({ output: 'crusty_chunks:fusion_bomb'})
    event.remove({ output: 'crusty_chunks:ordinance_inline_fusion_warhead_stage_1'})
    event.remove({ output: 'crusty_chunks:fusion_core'})
    event.remove({ output: 'crusty_chunks:ordinance_inline_fusion_warhead_stage_2'})
    event.remove({ output: 'crusty_chunks:implosion_lens'})
    event.remove({ output: 'crusty_chunks:fission_core'})
})

