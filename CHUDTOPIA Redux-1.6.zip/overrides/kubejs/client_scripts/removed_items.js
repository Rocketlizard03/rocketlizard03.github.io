ServerEvents.recipes(event => {
  // Remove all recipes that produce the Digital Miner
  event.remove({ output: 'mekanism:digital_miner' });
});

JEIEvents.hideItems(event => {
  event.hide('mekanism:digital_miner');
});
