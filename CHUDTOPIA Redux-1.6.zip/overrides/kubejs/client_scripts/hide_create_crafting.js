JEIEvents.hideRecipes(event => {
  if (!Client.player.stages.has('create')) {
    event.remove('create:mechanical_crafting');
  }
});
